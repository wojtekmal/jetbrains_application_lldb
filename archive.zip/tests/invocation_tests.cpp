#include <gtest/gtest.h>
#include <cstdio>

TEST(InvocationTest, CLIToolExecutesCorrectly)
{}